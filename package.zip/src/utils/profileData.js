export const staticProfile = {
    name: 'Ali Rajab',
    headline: 'Software Engineer  | Product Manager | Mobile Application Engineer | Flutter | Java | Web | Laravel | React.js | Vue.js | Junior Blockchain Engineer | Solidity | Python | SUI',
    location: 'Hama, Syria',
    contact: {
        email: 'alirajab.dev@gmail.com',
        phone: '+963-992840260',
        linktree: 'https://linktr.ee/alirajab',
    },
    summary: "Hello and welcome to my profile يامرحبا! About me, I'm a software engineer passionate about architecting scalable, high-impact solutions, I combine 5+ years of technical expertise with a relentless focus on performance, user experience, and clean architecture. My work spans web/mobile development (Flutter, Laravel, Next.js) and Web3 (SUI Network, Smart Contracts), with a proven track record of: <br><br>- Leading teams internationally to enhance the work flow while boosting productivity by 75%. <br><br> - Optimizing systems—cutting server load, refactoring slow components and APIs and optimizing the app security. <br><br>- Building cross-platform apps (50+ screens) and full-stack web apps with applying the best practices and choosing the (current) most efficient solutions.<br><br>I thrive in Agile environments, bridging stakeholder vision with technical execution—whether refining APIs, mentoring developers, or exploring blockchain’s potential.<br><br>My goal: Let the machine automates the tasks.<br><br>Let’s connect!<br>📩 Contact: alirajab.dev@gmail.com <br><br> For more about my work and to connect, visit my <a href='https://linktr.ee/alirajab'>Linktree</a>.",
    experience: [
        {
            job_title: "Web3 Product Manager",
            company: "GBCMobile",
            duration: "11/2024 – 07/2025",
            location: "Remotely (Kuwait)",
            description: "• Deployed gas-optimized Move contracts, distributing 1,000+ tokens and 50+ NFTs to users, directly driving a 70% increase in 45-day user retention. <br><br>• Spearheaded development of a DeFi dApp for real-time analytics, swaps, and Move-based rewards, serving 2,000+ holders with 95% uptime.<br><br>• Integrated 5+ SUI-compatible wallets for seamless user onboarding, achieving 90% successful connection rates."
        },
        {
      job_title: "Technical Project Manager",
      company: "Axis X Group",
      duration: "08/2023 – 02/2024",
      location: "Erbil, Iraq",
      description: "• Mentored a cross-functional team of 9 engineers in delivering features for a delivery system, driving a 75% productivity increase and 50% user base growth. <br><br>• Orchestrated efficient project management using ClickUp and streamlined Git repository management for multiple codebases, improving team collaboration and reducing feature delivery time by 80%. <br><br>• Translated stakeholder requirements into technical specs, prioritizing high-impact features that slashed customer support calls by 90% (merchants, clients, delivery personnel). <br><br>• Optimized system architecture by refactoring over 10 critical APIs, resulting in an 80% decrease in server load. <br><br>- Tech: ClickUp, Flutter, Laravel, Linux, Github, JMeter, GetX, Google Maps, Firebase."
    },
        {
      job_title: "Mobile Engineer",
      company: "Balafrreen",
      duration: "12/2022 – 08/2023",
      location: "Erbil, Iraq",
      description: "• Architected and developed a cross-platform mobile app (Flutter) from the ground up, featuring 30+ screens with complex navigation and responsive UI/UX.<br><br>• Boosted data accessibility by 80% and reduced server latency by 50% through backend optimizations (AWS) and cloud infrastructure tuning.<br><br>• Processed 10,000+ rows of flight/airline data, improving app response times by 90% via efficient data modeling. <br><br>• Increased app user base by 35% by integrating social sign-in (Google, Apple, Facebook).<br><br>• Tech: Flutter, BloC, Clean Architecture, AWS, JavaScript, XCode, HIVE"
    }
    ],
    education: [
        
        {
            degree: 'Bachelor, Information Engineering',
            institution: 'Al-Baath University',
            duration: 'September 2015 - October 2020',
        }
    ],
    skills: {
        'Project Management': {
            'Proficient': ['Team Leadership', 'Agile', 'ClickUp'],
            'Familiar': ['Jira']
        },
        'Mobile Application Development': {
            'Proficient': ['Flutter', 'Dart', 'Java', 'UI/UX design', 'REST API integration', 'Firebase', 'Google Play', 'App Store', 'App Gallery', 'POS (SUNMI)', 'Figma', 'XCode', 'JSON'],
            'Familiar': ['Swift', 'Objective-C']
        },
        'Web Development': {
            'Proficient': ['C#', '.Net core', 'Postman', 'PHP', 'Laravel', 'JavaScript', 'Node.js', 'Vue.js', 'HTML/CSS', 'Bootstrap', 'Tailwind CSS', 'Linux', 'Server Administration', 'AWS', 'Git', 'Github', 'Gitlab', 'Pinia'],
            'Familiar': ['Typescript', 'React.js', 'Next.js']
        },
        'Database Management': {
            'Proficient': ['SQL Server', 'MSSQL', 'MySQL', 'SQLite', 'PostgreSQL', 'MongoDB']
        }
    },
    projects: [
        {
            title: "Flight Ticket Reservation System",
            description: "- Built a dashboard for administrators to manage flights, reservations, users, and thier roles(+3).<br><br> - Enabled users to search among flights, make reservations, and manage their reservations.<br><br> - Utilized the Code-First approach to design and manage a database with 6+ tables in MSSQL.<br><br> - Implemented Razor page model for managing 15+ website pages and their associated logic.<br><br> - Added multilingual support for Arabic and English, catering to a diverse user base.",
            githubLink: "",
            liveLink: "",
            technologies: [".NET 6 (cross-platform)", "Bootstrap", "HTML", "CSS", "JS", "SQL Server"],
            image: "assets/img/profile_img.jpg"
        },
        {
            title: "Your Store",
            description: "- Comprehensive Ecommerce Mobile App: Developed a feature-rich mobile application for ecommerce using Flutter.<br><br> - Product Search: Integrated a powerful search functionality, allowing users to easily find products.- Favorites Management: Enabled users to effortlessly manage their favorite items.<br><br> - Order and Cart Management: Provided seamless order processing and cart management capabilities.<br><br> - Bloc Design Pattern: Utilized the Bloc design pattern to ensure efficient and scalable management of the app's business logic.",
            githubLink: "https://github.com/AliRajab12/flutter_ecommerce_app",
            liveLink: "https://www.youtube.com/watch?v=rD8zsHczDuM&list=PLVHI1VUbMtuItLu2XErbvLjB3-k8h78ny&index=2",
            technologies: ["Flutter", "Dart", "SQLite", "Figma"]
        },
    ],
    accomplishments: {
        certifications: [
            'AWS Cloud Technical Essesntials',
            'IBM Data Science Professional Certificate',
            'Thanks letter from The General Electricity Company'
        ]
    },
    languages: [
        'Arabic',
        'English',
    ]
};